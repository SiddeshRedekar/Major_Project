
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import User from '../src/models/User.js';
import Workout from '../src/models/Workout.js';
import { PLANS } from '../src/data/plans.js';

dotenv.config();
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/workout_guider_pro';

async function run() {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to DB');
  const user = await User.findOneAndUpdate(
    { email: 'demo@user.com' },
    { name: 'Demo User', email: 'demo@user.com', heightCm: 175, weightKg: 72, level: 'beginner' },
    { upsert: true, new: true }
  );

  const plan = PLANS.find(p => p.key === 'back_beginner');
  await Workout.create({
    userId: user._id,
    muscleGroup: plan.muscleGroup,
    planName: plan.name,
    exercises: plan.exercises.map(e => ({ ...e, weightKg: 20 })),
    date: new Date()
  });

  console.log('Seeded demo user and workout');
  await mongoose.disconnect();
}

run().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
