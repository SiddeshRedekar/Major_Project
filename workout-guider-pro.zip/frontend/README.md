
# Workout Guider Pro (Frontend)
- `npm install`
- `npm run dev` (http://localhost:5173)
- Backend must run at http://localhost:4000
- TailwindCSS configured via `styles.css` + `tailwind.config.js`
