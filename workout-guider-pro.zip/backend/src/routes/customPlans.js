
import express from 'express';
import CustomPlan from '../models/CustomPlan.js';
const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { userId, name, muscleGroup, level, exercises } = req.body;
    if (!userId || !name || !muscleGroup) return res.status(400).json({ error: 'userId, name, muscleGroup required' });
    const plan = await CustomPlan.create({ userId, name, muscleGroup, level: level || 'beginner', exercises: exercises || [] });
    res.status(201).json(plan);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.get('/', async (req, res) => {
  try {
    const { userId } = req.query;
    if (!userId) return res.status(400).json({ error: 'userId query is required' });
    const items = await CustomPlan.find({ userId }).sort({ createdAt: -1 });
    res.json(items);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await CustomPlan.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

export default router;
