
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import userRouter from './src/routes/users.js';
import workoutRouter from './src/routes/workouts.js';
import planRouter from './src/routes/plans.js';
import customPlanRouter from './src/routes/customPlans.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

const PORT = process.env.PORT || 4000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/workout_guider_pro';

mongoose.connect(MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

app.get('/', (_, res) => res.json({ ok: true, message: 'Workout Guider Pro API' }));

app.use('/api/users', userRouter);
app.use('/api/workouts', workoutRouter);
app.use('/api/plans', planRouter);
app.use('/api/custom-plans', customPlanRouter);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

app.listen(PORT, () => console.log(`🚀 API running on http://localhost:${PORT}`));
