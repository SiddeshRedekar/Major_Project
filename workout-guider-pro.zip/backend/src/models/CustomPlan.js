
import mongoose from 'mongoose';

const customExerciseSchema = new mongoose.Schema({
  name: { type: String, required: true },
  sets: { type: Number, required: true, min: 1 },
  reps: { type: String, required: true },
  targetWeightKg: { type: Number, default: 0 }
}, { _id: false });

const customPlanSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  muscleGroup: { type: String, required: true },
  level: { type: String, enum: ['beginner', 'intermediate', 'advanced'], default: 'beginner' },
  exercises: { type: [customExerciseSchema], default: [] }
}, { timestamps: true });

export default mongoose.model('CustomPlan', customPlanSchema);
