
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  heightCm: { type: Number, required: true },
  weightKg: { type: Number, required: true },
  level: { type: String, enum: ['beginner', 'intermediate', 'advanced'], default: 'beginner' }
}, { timestamps: true });

userSchema.virtual('bmi').get(function() {
  if (!this.heightCm || !this.weightKg) return null;
  const h = this.heightCm / 100;
  return Number((this.weightKg / (h*h)).toFixed(1));
});
userSchema.set('toJSON', { virtuals: true });

export default mongoose.model('User', userSchema);
