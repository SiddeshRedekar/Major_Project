
import express from 'express';
import User from '../models/User.js';
const router = express.Router();

router.post('/upsert', async (req, res) => {
  try {
    const { name, email, heightCm, weightKg, level } = req.body;
    if (!name || !email || !heightCm || !weightKg) return res.status(400).json({ error: 'name, email, heightCm, weightKg are required' });
    const doc = await User.findOneAndUpdate(
      { email },
      { name, email, heightCm, weightKg, level: level || 'beginner' },
      { new: true, upsert: true }
    );
    res.json(doc);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.get('/', async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return res.status(400).json({ error: 'email query is required' });
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

export default router;
