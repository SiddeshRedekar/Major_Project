
import express from 'express';
import { PLANS } from '../data/plans.js';
const router = express.Router();

router.get('/', (req, res) => {
  const { level, muscle } = req.query;
  let data = PLANS;
  if (level) data = data.filter(p => p.level === String(level).toLowerCase());
  if (muscle) data = data.filter(p => p.muscleGroup.toLowerCase() === String(muscle).toLowerCase());
  res.json(data);
});

router.get('/:key', (req, res) => {
  const p = PLANS.find(x => x.key === req.params.key);
  if (!p) return res.status(404).json({ error: 'plan not found' });
  res.json(p);
});

export default router;
