
import React from 'react';
export default function Nav({ current, setCurrent }) {
  const tabs = ['Profile', 'Plans', 'Workouts', 'Progress', 'Custom Plans'];
  return (
    <nav className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b border-slate-200">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="font-bold text-lg">🏋️ Workout Guider Pro</div>
        <div className="flex gap-2">
          {tabs.map(t => (
            <button key={t} onClick={() => setCurrent(t)} className={`btn ${current === t ? 'bg-slate-900 text-white' : 'bg-white'}`}>{t}</button>
          ))}
        </div>
      </div>
    </nav>
  );
}
