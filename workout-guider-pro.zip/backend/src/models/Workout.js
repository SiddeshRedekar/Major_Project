
import mongoose from 'mongoose';

const exerciseSchema = new mongoose.Schema({
  name: { type: String, required: true },
  sets: { type: Number, required: true, min: 1 },
  reps: { type: String, required: true },
  weightKg: { type: Number, default: 0 },
  notes: { type: String }
}, { _id: false });

const workoutSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  date: { type: Date, default: () => new Date() },
  muscleGroup: { type: String, required: true },
  planName: { type: String },
  exercises: { type: [exerciseSchema], default: [] }
}, { timestamps: true });

export default mongoose.model('Workout', workoutSchema);
