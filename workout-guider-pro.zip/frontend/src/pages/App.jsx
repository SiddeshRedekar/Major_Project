
import React, { useEffect, useMemo, useState } from 'react';
import Nav from '../components/Nav.jsx';
import PlanCard from '../components/PlanCard.jsx';
import ChartCard from '../components/ChartCard.jsx';

const API = 'http://localhost:4000/api';

export default function App() {
  const [current, setCurrent] = useState('Profile');
  const [email, setEmail] = useState('demo@user.com');
  const [user, setUser] = useState(null);
  const [plans, setPlans] = useState([]);
  const [muscle, setMuscle] = useState('All');
  const [level, setLevel] = useState('beginner');
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [workouts, setWorkouts] = useState([]);
  const [dailyStats, setDailyStats] = useState([]);
  const [streak, setStreak] = useState(0);
  const [customPlans, setCustomPlans] = useState([]);
  const [newCustom, setNewCustom] = useState({ name: '', muscleGroup: 'Back', level: 'beginner', exercises: [] });
  const [newExercise, setNewExercise] = useState({ name: '', sets: 3, reps: '10-12', targetWeightKg: 0 });

  useEffect(() => { fetch(`${API}/plans`).then(r => r.json()).then(setPlans).catch(console.error); }, []);

  useEffect(() => {
    if (!user) return;
    fetch(`${API}/workouts/stats/daily?userId=${user._id}`).then(r => r.json()).then(setDailyStats).catch(console.error);
    fetch(`${API}/workouts/stats/streak?userId=${user._id}`).then(r => r.json()).then(d => setStreak(d.streak)).catch(console.error);
    fetch(`${API}/custom-plans?userId=${user._id}`).then(r => r.json()).then(setCustomPlans).catch(console.error);
    fetch(`${API}/workouts?userId=${user._id}`).then(r => r.json()).then(setWorkouts).catch(console.error);
  }, [user?._id]);

  const upsertUser = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const payload = {
      name: form.get('name'),
      email: form.get('email'),
      heightCm: Number(form.get('heightCm')),
      weightKg: Number(form.get('weightKg')),
      level: form.get('level')
    };
    const res = await fetch(`${API}/users/upsert`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json();
    setUser(data); setLevel(data.level);
  };

  const loadUser = async () => {
    const res = await fetch(`${API}/users?email=${encodeURIComponent(email)}`);
    const data = await res.json();
    setUser(data); setLevel(data.level);
  };

  const filteredPlans = useMemo(() => plans
    .filter(p => (level ? p.level === level : true))
    .filter(p => (muscle === 'All' ? true : p.muscleGroup === muscle)), [plans, muscle, level]);

  const saveWorkout = async () => {
    if (!user || !selectedPlan) return;
    const payload = { userId: user._id, muscleGroup: selectedPlan.muscleGroup, planName: selectedPlan.name, exercises: selectedPlan.exercises };
    const res = await fetch(`${API}/workouts`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json();
    if (!data.error) { alert('Workout saved!'); setSelectedPlan(null); loadUser(); } else { alert('Error saving workout'); }
  };

  const addExerciseToCustom = () => {
    if (!newExercise.name) return;
    setNewCustom(c => ({ ...c, exercises: [...c.exercises, newExercise] }));
    setNewExercise({ name: '', sets: 3, reps: '10-12', targetWeightKg: 0 });
  };
  const saveCustomPlan = async () => {
    if (!user) return alert('Create/Load profile first');
    if (!newCustom.name) return;
    const payload = { ...newCustom, userId: user._id };
    const res = await fetch(`${API}/custom-plans`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json();
    if (!data.error) { setCustomPlans(x => [data, ...x]); setNewCustom({ name: '', muscleGroup: 'Back', level: 'beginner', exercises: [] }); alert('Custom plan saved'); }
    else alert('Error saving custom plan');
  };
  const deleteCustomPlan = async (id) => { await fetch(`${API}/custom-plans/${id}`, { method: 'DELETE' }); setCustomPlans(x => x.filter(p => p._id !== id)); };

  return (
    <div>
      <Nav current={current} setCurrent={setCurrent} />
      <main className="max-w-5xl mx-auto px-4 py-6 space-y-4">
        {current === 'Profile' && (
          <section className="section">
            <div className="h2 mb-2">Your Profile</div>
            <form onSubmit={upsertUser} className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input className="card" name="name" placeholder="Name" defaultValue="Demo User" required />
              <input className="card" name="email" placeholder="Email" defaultValue={email} required onChange={e => setEmail(e.target.value)} />
              <input className="card" name="heightCm" placeholder="Height (cm)" type="number" defaultValue={175} required />
              <input className="card" name="weightKg" placeholder="Weight (kg)" type="number" defaultValue={72} required />
              <select className="card" name="level" value={level} onChange={e => setLevel(e.target.value)}>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
              <button className="btn bg-slate-900 text-white" type="submit">Save/Update Profile</button>
            </form>
            <div className="mt-3 flex gap-2">
              <button className="btn" onClick={loadUser}>Load Profile</button>
              {user && (
                <div className="card">
                  <div><strong>{user.name}</strong> · Level: {user.level}</div>
                  <div className="small">BMI: <span className={`${user.bmi < 18.5 ? 'text-blue-600' : user.bmi < 25 ? 'text-green-600' : user.bmi < 30 ? 'text-yellow-600' : 'text-red-600'}`}>{user.bmi ?? 'N/A'}</span></div>
                </div>
              )}
            </div>
          </section>
        )}

        {current === 'Plans' && (
          <section className="section">
            <div className="flex items-end justify-between flex-wrap gap-3 mb-3">
              <div className="h2">Browse Plans</div>
              <div className="flex gap-2">
                <select className="card" value={muscle} onChange={(e) => setMuscle(e.target.value)}>
                  {['All','Back','Chest','Shoulders','Arms','Legs','Abs','Full Body'].map(m => <option key={m} value={m}>{m}</option>)}
                </select>
                <select className="card" value={level} onChange={(e) => setLevel(e.target.value)}>
                  {['beginner','intermediate','advanced'].map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredPlans.map(p => (<PlanCard key={p.key} plan={p} onSelect={setSelectedPlan} />))}
            </div>
            {selectedPlan && (
              <div className="mt-3 flex items-center gap-2">
                <div className="card">Selected: <strong>{selectedPlan.name}</strong></div>
                <button className="btn bg-slate-900 text-white" onClick={saveWorkout}>Log This Workout</button>
              </div>
            )}
          </section>
        )}

        {current === 'Workouts' && (
          <section className="section">
            <div className="h2 mb-2">Workout History</div>
            {!workouts.length && <p className="small">No workouts yet.</p>}
            <div className="space-y-2">
              {workouts.map(w => (
                <div key={w._id} className="card">
                  <div className="font-semibold">{new Date(w.date).toLocaleString()} — {w.muscleGroup} — {w.planName}</div>
                  <ul className="list-disc pl-6 small">
                    {w.exercises.map((e, i) => (<li key={i}>{e.name}: {e.sets} × {e.reps} @ {e.weightKg || 0} kg</li>))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}

        {current === 'Progress' && (
          <section className="section">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <ChartCard title="Total Sets per Day" data={dailyStats} dataKey="totalSets" />
              <ChartCard title="Total Weight per Day (kg)" data={dailyStats} dataKey="totalWeight" />
            </div>
            <div className="mt-3 card">
              <div className="h2">Streak</div>
              <div>You are on a <strong>{streak}-day</strong> workout streak! 🔥</div>
            </div>
            <div className="mt-3 card">
              <div className="h2">Load Calculator</div>
              <LoadCalculator />
            </div>
          </section>
        )}

        {current === 'Custom Plans' && (
          <section className="section">
            <div className="h2 mb-2">Build Your Own Plan</div>
            <div className="grid md:grid-cols-2 gap-3">
              <div className="card space-y-2">
                <input className="card" placeholder="Plan name" value={newCustom.name} onChange={e => setNewCustom(c => ({ ...c, name: e.target.value }))} />
                <select className="card" value={newCustom.muscleGroup} onChange={e => setNewCustom(c => ({ ...c, muscleGroup: e.target.value }))}>
                  {['Back','Chest','Shoulders','Arms','Legs','Abs','Full Body'].map(m => <option key={m} value={m}>{m}</option>)}
                </select>
                <select className="card" value={newCustom.level} onChange={e => setNewCustom(c => ({ ...c, level: e.target.value }))}>
                  {['beginner','intermediate','advanced'].map(l => <option key={l} value={l}>{l}</option>)}
                </select>
                <div className="h2">Exercises</div>
                <div className="grid grid-cols-2 gap-2">
                  <input className="card" placeholder="Name" value={newExercise.name} onChange={e => setNewExercise(s => ({ ...s, name: e.target.value }))} />
                  <input className="card" type="number" placeholder="Sets" value={newExercise.sets} onChange={e => setNewExercise(s => ({ ...s, sets: Number(e.target.value) }))} />
                  <input className="card" placeholder="Reps" value={newExercise.reps} onChange={e => setNewExercise(s => ({ ...s, reps: e.target.value }))} />
                  <input className="card" type="number" placeholder="Target Weight (kg)" value={newExercise.targetWeightKg} onChange={e => setNewExercise(s => ({ ...s, targetWeightKg: Number(e.target.value) }))} />
                </div>
                <button className="btn" onClick={addExerciseToCustom}>Add Exercise</button>
                {!!newCustom.exercises.length && (
                  <ul className="list-disc pl-6 small">
                    {newCustom.exercises.map((e, i) => (<li key={i}>{e.name} — {e.sets} x {e.reps} @ {e.targetWeightKg} kg</li>))}
                  </ul>
                )}
                <button className="btn bg-slate-900 text-white" onClick={saveCustomPlan}>Save Custom Plan</button>
              </div>
              <div className="card">
                <div className="h2 mb-2">Your Saved Custom Plans</div>
                {!customPlans.length && <div className="small">No custom plans yet.</div>}
                <div className="space-y-2">
                  {customPlans.map(p => (
                    <div key={p._id} className="card">
                      <div className="font-semibold">{p.name} · {p.muscleGroup} · {p.level}</div>
                      <ul className="list-disc pl-6 small">
                        {p.exercises.map((e, i) => (<li key={i}>{e.name} — {e.sets} x {e.reps} @ {e.targetWeightKg} kg</li>))}
                      </ul>
                      <div className="mt-2"><button className="btn" onClick={() => deleteCustomPlan(p._id)}>Delete</button></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

function LoadCalculator() {
  const [oneRm, setOneRm] = React.useState(80);
  const [reps, setReps] = React.useState(8);
  const estPct = (r) => Math.max(0.5, Math.min(1, 1 - (r - 1) * 0.03));
  const weight = Math.round(oneRm * estPct(reps));
  return (
    <div className="flex items-center gap-2">
      <input className="card" type="number" value={oneRm} onChange={e => setOneRm(Number(e.target.value))} />
      <span className="small">1RM (kg)</span>
      <input className="card" type="number" value={reps} onChange={e => setReps(Number(e.target.value))} />
      <span className="small">reps → Suggested load ≈ <strong>{weight} kg</strong></span>
    </div>
  );
}
