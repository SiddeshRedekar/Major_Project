
import React from 'react';
export default function PlanCard({ plan, onSelect }) {
  return (
    <div className="card">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{plan.name}</h3>
        <span className="small">Level: {plan.level}</span>
      </div>
      <div className="small mb-2">{plan.muscleGroup}</div>
      <ul className="list-disc pl-6">
        {plan.exercises.map((e, i) => (<li key={i}>{e.name} — {e.sets} x {e.reps}</li>))}
      </ul>
      <div className="mt-3"><button className="btn" onClick={() => onSelect(plan)}>Select</button></div>
    </div>
  );
}
