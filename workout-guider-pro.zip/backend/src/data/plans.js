
export const PLANS = [
  { key:'back_beginner', name:'Back Day (Beginner)', muscleGroup:'Back', level:'beginner', exercises:[
    { name:'Lat Pulldown', sets:3, reps:'10-12', weightKg:0 },
    { name:'Seated Cable Row', sets:3, reps:'10-12', weightKg:0 },
    { name:'DB Row (each)', sets:3, reps:'8-10', weightKg:0 },
    { name:'Back Extensions', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'back_intermediate', name:'Back Day (Intermediate)', muscleGroup:'Back', level:'intermediate', exercises:[
    { name:'Pull-Ups / Assisted', sets:4, reps:'6-10', weightKg:0 },
    { name:'Barbell Row', sets:4, reps:'6-8', weightKg:0 },
    { name:'Single-Arm DB Row', sets:3, reps:'8-10', weightKg:0 },
    { name:'Face Pulls', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'back_advanced', name:'Back Day (Advanced)', muscleGroup:'Back', level:'advanced', exercises:[
    { name:'Weighted Pull-Ups', sets:5, reps:'4-6', weightKg:0 },
    { name:'Pendlay Row', sets:5, reps:'5', weightKg:0 },
    { name:'Chest-Supported Row', sets:4, reps:'8-10', weightKg:0 },
    { name:'Straight-Arm Pulldown', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'chest_beginner', name:'Chest Day (Beginner)', muscleGroup:'Chest', level:'beginner', exercises:[
    { name:'Machine Chest Press', sets:3, reps:'10-12', weightKg:0 },
    { name:'DB Bench Press', sets:3, reps:'8-10', weightKg:0 },
    { name:'Incline DB Press', sets:3, reps:'10-12', weightKg:0 },
    { name:'Cable Fly', sets:2, reps:'12-15', weightKg:0 }
  ]},
  { key:'chest_intermediate', name:'Chest Day (Intermediate)', muscleGroup:'Chest', level:'intermediate', exercises:[
    { name:'Barbell Bench Press', sets:4, reps:'6-8', weightKg:0 },
    { name:'Incline Barbell Press', sets:4, reps:'6-8', weightKg:0 },
    { name:'Weighted Dips', sets:3, reps:'6-10', weightKg:0 },
    { name:'Cable Fly (H->L)', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'chest_advanced', name:'Chest Day (Advanced)', muscleGroup:'Chest', level:'advanced', exercises:[
    { name:'Pause Bench Press', sets:5, reps:'3-5', weightKg:0 },
    { name:'Incline DB Press (heavy)', sets:4, reps:'6-8', weightKg:0 },
    { name:'Weighted Dips', sets:4, reps:'6-8', weightKg:0 },
    { name:'Cable Fly (drop)', sets:3, reps:'10-12', weightKg:0 }
  ]},
  { key:'shoulders_beginner', name:'Shoulders (Beginner)', muscleGroup:'Shoulders', level:'beginner', exercises:[
    { name:'Seated DB Press', sets:3, reps:'10-12', weightKg:0 },
    { name:'Lateral Raise', sets:3, reps:'12-15', weightKg:0 },
    { name:'Rear Delt Fly', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'shoulders_intermediate', name:'Shoulders (Intermediate)', muscleGroup:'Shoulders', level:'intermediate', exercises:[
    { name:'Overhead Press', sets:4, reps:'5-8', weightKg:0 },
    { name:'DB Lateral Raise', sets:4, reps:'10-12', weightKg:0 },
    { name:'Face Pulls', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'shoulders_advanced', name:'Shoulders (Advanced)', muscleGroup:'Shoulders', level:'advanced', exercises:[
    { name:'Push Press', sets:5, reps:'3-5', weightKg:0 },
    { name:'Lateral Raise (partials)', sets:4, reps:'12-15', weightKg:0 },
    { name:'Rear Delt Row', sets:4, reps:'10-12', weightKg:0 }
  ]},
  { key:'arms_beginner', name:'Arms (Beginner)', muscleGroup:'Arms', level:'beginner', exercises:[
    { name:'Cable Curl', sets:3, reps:'12-15', weightKg:0 },
    { name:'Triceps Rope Pushdown', sets:3, reps:'12-15', weightKg:0 },
    { name:'Hammer Curl', sets:2, reps:'10-12', weightKg:0 }
  ]},
  { key:'arms_intermediate', name:'Arms (Intermediate)', muscleGroup:'Arms', level:'intermediate', exercises:[
    { name:'Barbell Curl', sets:4, reps:'8-10', weightKg:0 },
    { name:'Skull Crushers', sets:4, reps:'8-10', weightKg:0 },
    { name:'Incline DB Curl', sets:3, reps:'10-12', weightKg:0 }
  ]},
  { key:'arms_advanced', name:'Arms (Advanced)', muscleGroup:'Arms', level:'advanced', exercises:[
    { name:'Preacher Curl (heavy)', sets:5, reps:'6-8', weightKg:0 },
    { name:'Close-Grip Bench', sets:5, reps:'5-6', weightKg:0 },
    { name:'Cable Curl (drop)', sets:3, reps:'10-12', weightKg:0 }
  ]},
  { key:'legs_beginner', name:'Legs (Beginner)', muscleGroup:'Legs', level:'beginner', exercises:[
    { name:'Goblet Squat', sets:3, reps:'10-12', weightKg:0 },
    { name:'Leg Press', sets:3, reps:'12-15', weightKg:0 },
    { name:'Leg Curl', sets:3, reps:'12-15', weightKg:0 },
    { name:'Calf Raise', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'legs_intermediate', name:'Legs (Intermediate)', muscleGroup:'Legs', level:'intermediate', exercises:[
    { name:'Back Squat', sets:5, reps:'5', weightKg:0 },
    { name:'Romanian Deadlift', sets:4, reps:'6-8', weightKg:0 },
    { name:'Walking Lunges', sets:3, reps:'10 each', weightKg:0 },
    { name:'Seated Calf Raise', sets:4, reps:'10-12', weightKg:0 }
  ]},
  { key:'legs_advanced', name:'Legs (Advanced)', muscleGroup:'Legs', level:'advanced', exercises:[
    { name:'Front Squat', sets:5, reps:'3-5', weightKg:0 },
    { name:'Deadlift', sets:3, reps:'3-5', weightKg:0 },
    { name:'Bulgarian Split Squat', sets:4, reps:'8-10', weightKg:0 },
    { name:'Standing Calf Raise', sets:4, reps:'6-8', weightKg:0 }
  ]},
  { key:'abs_beginner', name:'Abs/Core (Beginner)', muscleGroup:'Abs', level:'beginner', exercises:[
    { name:'Plank', sets:3, reps:'30-45s', weightKg:0 },
    { name:'Dead Bug', sets:3, reps:'10-12', weightKg:0 },
    { name:'Crunches', sets:3, reps:'12-15', weightKg:0 }
  ]},
  { key:'abs_intermediate', name:'Abs/Core (Intermediate)', muscleGroup:'Abs', level:'intermediate', exercises:[
    { name:'Hanging Knee Raise', sets:3, reps:'10-12', weightKg:0 },
    { name:'Cable Crunch', sets:3, reps:'12-15', weightKg:0 },
    { name:'Side Plank', sets:3, reps:'30-45s', weightKg:0 }
  ]},
  { key:'abs_advanced', name:'Abs/Core (Advanced)', muscleGroup:'Abs', level:'advanced', exercises:[
    { name:'Hanging Leg Raise', sets:4, reps:'8-12', weightKg:0 },
    { name:'Ab Wheel Rollout', sets:4, reps:'8-12', weightKg:0 },
    { name:'Weighted Plank', sets:3, reps:'30-45s', weightKg:0 }
  ]},
  { key:'full_beginner', name:'Full Body (Beginner)', muscleGroup:'Full Body', level:'beginner', exercises:[
    { name:'Goblet Squat', sets:3, reps:'10-12', weightKg:0 },
    { name:'DB Bench Press', sets:3, reps:'8-10', weightKg:0 },
    { name:'Lat Pulldown', sets:3, reps:'10-12', weightKg:0 }
  ]},
  { key:'full_intermediate', name:'Full Body (Intermediate)', muscleGroup:'Full Body', level:'intermediate', exercises:[
    { name:'Back Squat', sets:4, reps:'5-8', weightKg:0 },
    { name:'Overhead Press', sets:4, reps:'5-8', weightKg:0 },
    { name:'Barbell Row', sets:4, reps:'6-8', weightKg:0 }
  ]},
  { key:'full_advanced', name:'Full Body (Advanced)', muscleGroup:'Full Body', level:'advanced', exercises:[
    { name:'Deadlift', sets:3, reps:'3-5', weightKg:0 },
    { name:'Bench Press', sets:5, reps:'3-5', weightKg:0 },
    { name:'Weighted Pull-Up', sets:4, reps:'4-6', weightKg:0 }
  ]}
];
