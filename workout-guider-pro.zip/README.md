
# Workout Guider Pro — Full Stack (MERN)

Now includes **all major muscle groups**, **Tailwind UI**, **Progress charts**, **Workout streak**, and a **Custom Plan Builder**.

## Quick Start

### Backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
# optional demo data
npm run seed
```

### Frontend
```bash
cd ../frontend
npm install
npm run dev
```

## API (high level)
- Plans (built-in): `GET /api/plans?level=&muscle=`
- Users: `POST /api/users/upsert`, `GET /api/users?email=`
- Workouts: `POST /api/workouts`, `GET /api/workouts?userId=`, `GET /api/workouts/stats/daily?userId=`, `GET /api/workouts/stats/streak?userId=`
- Custom Plans: `POST /api/custom-plans`, `GET /api/custom-plans?userId=`, `DELETE /api/custom-plans/:id`
