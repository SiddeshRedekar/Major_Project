
import express from 'express';
import Workout from '../models/Workout.js';
import mongoose from 'mongoose';
const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { userId, muscleGroup, planName, exercises, date } = req.body;
    if (!userId || !muscleGroup || !exercises) return res.status(400).json({ error: 'userId, muscleGroup, exercises are required' });
    const workout = await Workout.create({
      userId, muscleGroup, planName: planName || null, exercises, date: date ? new Date(date) : undefined
    });
    res.status(201).json(workout);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.get('/', async (req, res) => {
  try {
    const { userId, muscleGroup } = req.query;
    if (!userId) return res.status(400).json({ error: 'userId query is required' });
    const q = { userId };
    if (muscleGroup) q.muscleGroup = muscleGroup;
    const items = await Workout.find(q).sort({ date: -1 });
    res.json(items);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.get('/stats/daily', async (req, res) => {
  try {
    const { userId } = req.query;
    if (!userId) return res.status(400).json({ error: 'userId query is required' });
    const items = await Workout.aggregate([
      { $match: { userId: new mongoose.Types.ObjectId(userId) } },
      { $unwind: '$exercises' },
      { $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } },
          totalSets: { $sum: '$exercises.sets' },
          totalWeight: { $sum: { $multiply: ['$exercises.sets', '$exercises.weightKg'] } }
        } 
      },
      { $sort: { _id: 1 } }
    ]);
    res.json(items);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

router.get('/stats/streak', async (req, res) => {
  try {
    const { userId } = req.query;
    if (!userId) return res.status(400).json({ error: 'userId query is required' });
    const days = await Workout.aggregate([
      { $match: { userId: new mongoose.Types.ObjectId(userId) } },
      { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } }, count: { $sum: 1 } } },
      { $sort: { _id: -1 } }
    ]);
    const today = new Date();
    let cursor = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
    let streak = 0;
    const daySet = new Set(days.map(d => d._id));
    while (true) {
      const key = cursor.toISOString().slice(0,10);
      if (daySet.has(key)) { streak += 1; cursor = new Date(cursor.getTime() - 86400000); } else break;
    }
    res.json({ streak });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

export default router;
